﻿/*
//Ethan Havertape
//CIS 199-01
//Final
//12/7/2024
 */

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Warehouse
{
    internal class Program
    {
        static void Main(string[] args)
        {
            // 1. Create 5 product objects with different property values
            Product product1 = new Product(9873, 250, "Paper Towels", "Brawny", "Kitchen Supplies");
            Product product2 = new Product(1743, 100, "Toilet Paper", "Charmin", "Toiletries");
            Product product3 = new Product(3465, 75, "Power Drill", "Milwaukee", "Tools");
            Product product4 = new Product(6778, 125, "Cat Food", "Chewy", "Pets");
            Product product5 = new Product(7454, 25, "Mattress", "Tempur-Pedic", "Furniture");

            // 2. Define an array of product objects and store the products created in part 1
            Product[] products = new Product[] { product1, product2, product3, product4, product5 };

            // 3. Call DisplayProducts method to display the product information

            Console.WriteLine("Product Information:\n");
            DisplayProducts(products);

            // 4. Modify product information. You must modify each object and use both the IsInStock() and NotInStock() methods.
            product1.IsInStock();
            product2.IsInStock();
            product3.NotInStock();
            product4.NotInStock();
            product5.IsInStock();

            product3.ProductName = "Electric Drill";
            product4.ProductAmount = 100;
            // 5. Redisplay product information after changes by calling DisplayProducts method. 

            Console.WriteLine("\nUpdated Product Information:\n");
            DisplayProducts(products);
        }

        // 3. Complete the DisplayProducts method to display the information for each product. Must use foreach loop.
        private static void DisplayProducts(Product[] products)
        {
            foreach (Product product in products)
            {
                Console.WriteLine(product.ToString());
                Console.WriteLine();
            }
        }
    }
}
