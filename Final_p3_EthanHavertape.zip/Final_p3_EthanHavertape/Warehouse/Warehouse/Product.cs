﻿//Ethan Havertape
//CIS 199-01
//Final
//12/7/2024
using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;

namespace Warehouse
{
    internal class Product
    {
        // 1. Define private fields

        private int _productID;
        private int _productAmount;
        private bool _stock;

        // 2. Complete the constructor. Be sure to add correct parameters and logic.
        public Product(int productID, int productAmount, string productName, string productManufacturer, string productType)
        {
            if (productID <= 0 || productID >= 9999)
                Console.WriteLine("Enter valid product ID");
            _productID = productID;

            if (productAmount < 0)
                Console.WriteLine("Enter valid product amount");
            _productAmount = productAmount;

            ProductName = productName;
            ProductManufacturer = productManufacturer;
            ProductType = productType;

        }

        // 1. Complete properties
        public int ProductID // Ensure you add required validation (between 0 and 9999 inclusive)
        {
            get
            { return _productID; }
            set
            {
                if (value <= 0 || value >= 9999)
                    Console.WriteLine("Enter valid product ID");
                _productID = value;
            }
        }

        public int ProductAmount // Ensure you add required validation (above 0 exclusive)
        {
            get 
            { return _productAmount; }
            set
            {
                if (value < 0)
                    Console.WriteLine("Enter valid product amount");
                _productAmount = value;
            }
        }

        public string ProductName
        {
            get; set;
        }

        public string ProductManufacturer
        {
            get; set; 
        }

        public string ProductType
        {
            get; set; 
        }


        // 3. Add methods from part 3
        public void IsInStock()
        {
            _stock = true;
        }

        public void NotInStock()
        {
            _stock = false;
        }

        public bool StockStatus()
        {
            return _stock;
        }

        // 4. Implement ToString() override
        public override string ToString()
        {
            return $"Product Name: {ProductName}\n" +
                $"ID: {ProductID}\n" +
                $"Manufacturer: {ProductManufacturer}\n" +
                $"Type: {ProductType}\n" +
                $"Amount: {ProductAmount}\n" +
                $"In stock?: {StockStatus()}";
        }

    }
}